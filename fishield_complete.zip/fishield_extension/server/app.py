"""
FiShield Optional Backend Server
Runs a Flask API that the extension can call for server-side inference.
Use this if you want to run a heavier model (XGBoost, deep learning) server-side.

Usage:
  pip install flask scikit-learn joblib
  python server/app.py
"""
from flask import Flask, request, jsonify
from flask_cors import CORS
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

app = Flask(__name__)
CORS(app)

# Import feature extractor from parent dir
from build_fishield_extension import extract_features

try:
    import joblib
    model = joblib.load('server/model.pkl')
    print("[✓] Loaded server model")
except Exception as e:
    model = None
    print(f"[!] No server model found ({e}) — run build_fishield_extension.py first")

@app.route('/classify', methods=['POST'])
def classify():
    data = request.get_json()
    url  = data.get('url', '')
    if not url:
        return jsonify({"error": "No URL provided"}), 400
    
    if model is None:
        return jsonify({"error": "Model not loaded"}), 503

    features = [extract_features(url)]
    prob     = model.predict_proba(features)[0][1]
    
    verdict = 'PHISHING' if prob >= 0.70 else 'SUSPICIOUS' if prob >= 0.40 else 'SAFE'
    return jsonify({
        "url": url,
        "verdict": verdict,
        "confidence": round(prob * 100),
        "phishing_probability": round(prob, 4)
    })

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)

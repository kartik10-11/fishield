
chrome.runtime.sendMessage({ type: 'GET_RESULT' }, (result) => {
  const body = document.getElementById('body');
  if (!result) {
    body.innerHTML = '<div class="loading" style="opacity:.6">No analysis yet for this page.<br><small style="font-size:11px">Navigate to a URL to scan it.</small></div>';
    return;
  }

  const color = result.color;
  const emoji = result.verdict === 'PHISHING' ? '⛔' : result.verdict === 'SUSPICIOUS' ? '⚠️' : '✅';
  const signalsHTML = (result.reasons || []).map(r => `<div class="signal">${r}</div>`).join('');

  body.innerHTML = `
    <div class="verdict-card" style="background:${color}22;border:1px solid ${color}55">
      <div class="verdict-label">Verdict ${emoji}</div>
      <div class="verdict-text" style="color:${color}">${result.verdict}</div>
    </div>
    <div class="confidence-row">
      <div class="conf-bar">
        <div class="conf-fill" style="width:${result.confidence}%;background:${color}"></div>
      </div>
      <div class="conf-pct" style="color:${color}">${result.confidence}%</div>
    </div>
    <div class="url-box">${result.url}</div>
    <div class="signals">${signalsHTML || '<div class="signal">🟢 No suspicious signals detected</div>'}</div>
  `;
});
